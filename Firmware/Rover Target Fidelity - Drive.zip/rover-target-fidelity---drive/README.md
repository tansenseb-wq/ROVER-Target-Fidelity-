# Rover Target Fidelity — App de conducción (Arduino App Lab)

App de **Arduino App Lab** para el UNO Q que conduce el rover de 6 ruedas. Usa
la arquitectura de doble cerebro de la placa: el **sketch (MCU/STM32)** hace el
control en tiempo real y el **Python (Linux/MPU)** supervisa, comunicándose por
el **Router Bridge**.

> Esta es la versión App Lab del firmware. Reemplaza al `.ino` suelto de Arduino
> IDE — el UNO Q se programa como una *app* con las dos mitades.

---

## Estructura del proyecto (formato App Lab)

```
rover_drive/
├── app.yaml              # manifiesto de la app (nombre, bricks, puertos)
├── sketch/
│   ├── sketch.ino        # lado MCU (STM32): control en tiempo real
│   └── sketch.yaml       # placa (FQBN) y librerías del sketch
└── python/
    └── main.py           # lado Linux (MPU): supervisión y logging
```

Esta es la estructura oficial de una app de App Lab: un `app.yaml`, una carpeta
`sketch/` con el `.ino` para el STM32, y una carpeta `python/` con el `main.py`
para el lado Linux.

---

## Cómo se reparte el trabajo entre las dos mitades

**El MCU (sketch) conduce.** Todo lo que no puede esperar vive ahí: leer el
radio, calcular la dirección Ackermann, rampar la tracción, cortar por seguridad.

**El Linux (Python) supervisa.** No conduce — le pide telemetría al MCU por el
Bridge y la registra. Es el lugar natural para lo que sí puede esperar unos
milisegundos: logs, y más adelante la visión y la navegación.

La razón de la división: Linux no es de tiempo real. Si la tracción viviera en
Python y el sistema operativo tiene un hipo, el rover se queda sin frenos. Por
eso el control crítico está en el MCU y Python es solo la capa de supervisión.

---

## El Bridge (comunicación entre las dos mitades)

El sketch expone dos funciones que Python llama como si fueran locales:

| Función | Lado | Qué hace |
|---|---|---|
| `get_telemetry()` | MCU expone, Python llama | Devuelve el estado (armado, PWM, voltaje, canales, enlace) como string `k=v`. |
| `soft_stop()` | MCU expone, Python llama | Freno remoto extra desde Linux (ej. si la visión detecta un obstáculo). NO reemplaza al failsafe del MCU. |

---

## Cableado

### Tracción
| Señal | Pin | | Señal | Pin |
|---|---|---|---|---|
| Driver IZQ RPWM | D5 | | Driver DER RPWM | D9 |
| Driver IZQ LPWM | D6 | | Driver DER LPWM | D10 |
| Driver IZQ EN | D7 | | Driver DER EN | D8 |

### Dirección (PCA9685 por I2C3)
| Señal | Pin | | Servo | Canal PCA | Rueda |
|---|---|---|---|---|---|
| SDA | A4 | | SV_FL | 0 | delantera izq |
| SCL | A5 | | SV_FR | 1 | delantera der |
| | | | SV_RL | 2 | trasera izq |
| | | | SV_RR | 3 | trasera der |

### Radio (FLI14+ por iBUS)
| Señal | Pin | Nota |
|---|---|---|
| iBUS | RX del UART (`Serial1`) | El FLI14+ solo saca iBUS |
| VCC | 5V del buck | 4-6.5V, **nunca 12V** |
| GND | GND común | |

### Sensado
| Señal | Pin | Nota |
|---|---|---|
| IS driver IZQ | A2 | A0/A1 no toleran 5V |
| IS driver DER | A3 | |
| VBAT (divisor 33k/10k) | A0 | protegido por el divisor |

---

## Mapa del control (FS-i6X)

| Canal | Control | Función |
|---|---|---|
| CH1 | palanca der, horizontal | dirección |
| CH2 | palanca der, vertical | acelerador |
| CH3 | palanca izq, vertical | límite de velocidad |
| CH5 | interruptor | ARMADO (seguro) |
| CH14 | — | RSSI (no usar) |

**Para moverse hay que ARMAR** (CH5) con el acelerador en neutro.

---

## Funciones del sketch (MCU)

| Función | Qué hace |
|---|---|
| `setup()` | Arranca el Bridge, el iBUS, el PCA9685, centra servos, registra las funciones del Bridge. |
| `loop()` | Atiende el Bridge → lee radio → failsafe → armado → batería → dirección → tracción → rampa. |
| `get_telemetry()` | (Bridge) Devuelve el estado como string para Python. |
| `soft_stop()` | (Bridge) Freno remoto desde Python. |
| `applySteering()` | Palanca → radio de giro → ángulo de cada esquina (Ackermann). |
| `writeSteer()` | Ángulo de rueda → pulso del servo (con trim). |
| `applyThrottle()` | Acelerador + límite → PWM objetivo por lado, con mezcla suave de giro. |
| `rampAndDrive()` | Rampa hacia el objetivo y escribe a los drivers. |
| `driveSide()` | PWM con signo → medio-puente del BTS7960. |
| `readIbus()` | Parsea las tramas iBUS (32 bytes, checksum). |
| `checkFailsafe()` | Sin señal en 500ms → para y desarma. |
| `readArm()` | Lee el switch de armado (solo arma con acelerador neutro). |
| `readVbat()` | Lee el voltaje por el divisor. |

## Funciones del Python (Linux)

| Función | Qué hace |
|---|---|
| `parse_telemetry()` | Convierte el string `k=v` del Bridge en un dict. |
| `main()` | Pide telemetría 5×/s, la registra en CSV, vigila la batería y aplica freno remoto si baja de 10.5V. |

---

## Seguridad

- **Failsafe (MCU):** sin señal del radio → para y desarma. No sigue con el
  último comando.
- **Armado obligatorio (MCU):** sin CH5, la tracción está muerta. Solo arma con
  el acelerador en neutro.
- **Rampa (MCU):** el PWM nunca salta (evita el pico de stall al arrancar).
- **Freno remoto (Python→MCU):** capa extra por el Bridge, sin reemplazar el
  failsafe del MCU.
- **Batería:** el MCU no habilita drivers bajo 10.5V; Python además avisa y frena.

---

## Cómo cargarlo en App Lab

1. Empareja (bind) el FLI14+ con el FS-i6X.
2. En Arduino App Lab, crea una app nueva o abre esta carpeta (`rover_drive`).
3. App Lab detecta el `app.yaml`. Las librerías del `sketch.yaml`
   (`Arduino_RouterBridge`, `Adafruit PWM Servo Driver`) se instalan al compilar.
4. Verifica el UART del iBUS y el mapeo de pines PWM (el core sobre Zephyr puede
   diferir de los D5/D6/D9/D10 clásicos).
5. Dale **Run**: App Lab compila el sketch al STM32 y arranca el `main.py` en Linux.
6. Con el rover sobre bloques, arma (CH5) y prueba dirección y tracción antes de
   bajarlo al suelo.

> Nota: el monitor serial de App Lab por WiFi no muestra la salida del lado
> Arduino; para ver los `Serial.print` del MCU conéctate por USB-C. La consola
> de Python sí funciona por red.

---

## Parámetros a calibrar

| Constante | Dónde | Qué es |
|---|---|---|
| `SERVO_MIN/MID/MAX`, `servoTrim[]` | sketch | Pulsos y centro de cada servo |
| `MAX_STEER_DEG` | sketch | Ángulo máximo de rueda (límite del king pin) |
| `R_MIN` | sketch | Radio de giro mínimo |
| `IBUS_SERIAL` | sketch | UART del receptor |
| `POLL_HZ`, `VBAT_WARN/CRIT` | python | Frecuencia de supervisión y umbrales |

---

## Requisitos mecánicos previos

Sin esto, los servos no giran las ruedas por más que el código esté bien:

1. **Perno rey con rodamientos:** el peso de la rueda (75N la delantera) NO pasa
   por el eje del servo — lo cargan rodamientos dedicados.
2. **Scrub radius ≈ 0:** el eje de dirección pasa por el centro de la huella.

---

## Notas de verificación (armado de la app)

Al ordenar los archivos sueltos en la estructura oficial de App Lab
(`app.yaml` + `sketch/` + `python/`) se corrigieron dos cosas contra la API
real del UNO Q (docs.arduino.cc/software/app-lab + foro de Arduino):

- **`sketch/sketch.yaml`**: la FQBN real es `arduino:zephyr:unoq` (plataforma
  `arduino:zephyr`), no `arduino:stm32u5:unoq` — esta última no existe.
- **`python/main.py`**: el Bridge de Python no se instancia. Es
  `from arduino.app_utils import App, Bridge` y se llama como
  `Bridge.call("nombre", ...)` a nivel de clase; el bucle se entrega a
  `App.run(user_loop=loop)` en vez de un `while True` manual.

Sin verificar (dejado tal cual venía, revisar contra tu propia placa antes de
confiar en ello):

- **`Serial1` para el iBUS** (`sketch.ino`): según el foro de Arduino, los
  pines D0/D1 del header corresponden a `Serial1` (USART1) y son un puerto
  de hardware separado del que usa internamente el Router Bridge (LPUART1),
  así que no deberían chocar — pero al resetear el MCU, Zephyr manda un
  mensaje de boot por ese mismo `Serial1`, que el parser de iBUS descarta
  por checksum. Confírmalo con tu propia placa: la documentación de este
  puerto nuevo cambia seguido.
