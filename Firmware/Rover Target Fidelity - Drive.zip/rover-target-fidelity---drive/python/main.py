#!/usr/bin/env python3
# ============================================================================
#  ROVER "Target Fidelity"  —  App Lab · lado Linux (Python / MPU)
#  SEBDev / Stardance
#
#  Esta mitad NO conduce. La conduccion vive en el sketch del MCU, en tiempo
#  real. Aca arriba, en el Linux del UNO Q, solo SUPERVISO: le pido telemetria
#  al MCU por el Bridge y la registro. Es el lugar natural para lo que si puede
#  esperar unos milisegundos — logs, y mas adelante la vision y la navegacion.
#
#  Por que la division: Linux no es de tiempo real. Si dejara la traccion aca y
#  el sistema operativo tiene un hipo, el rover se queda sin frenos. Por eso el
#  control critico esta abajo (MCU) y esto es la capa de supervision.
#
#  El Bridge me deja llamar funciones del sketch como si fueran de Python:
#    - get_telemetry() -> string "arm=..,pwmL=..,vbat=.." que parseo
#    - soft_stop()     -> freno remoto extra (ej. si la vision ve un obstaculo)
# ============================================================================

import time
from datetime import datetime
from arduino.app_utils import App, Bridge   # API real del Bridge de App Lab

# ---------------------------------------------------------------------------
# Configuracion
# ---------------------------------------------------------------------------
POLL_HZ    = 5                       # cada cuanto pido telemetria (veces/seg)
LOG_PATH   = "rover_drive_log.csv"   # donde guardo el registro
VBAT_WARN  = 11.0                    # aviso si la bateria baja de aqui
VBAT_CRIT  = 10.5                    # critico: freno remoto de seguridad
PERIOD     = 1.0 / POLL_HZ
warned     = False


def parse_telemetry(raw: str) -> dict:
    """Convierte 'arm=1,pwmL=120,vbat=11.8' en un dict tipado."""
    out = {}
    if not raw:
        return out
    for pair in raw.split(","):
        if "=" not in pair:
            continue
        k, v = pair.split("=", 1)
        try:
            out[k] = float(v) if "." in v else int(v)
        except ValueError:
            out[k] = v
    return out


def loop():
    """Un ciclo de supervision. App.run() la llama repetidamente."""
    global warned

    # Pido la telemetria al sketch por el Bridge (Bridge.call es de clase, sin instanciar)
    raw = Bridge.call("get_telemetry")
    t = parse_telemetry(raw)

    armed = t.get("arm", 0)
    vbat  = t.get("vbat", 0.0)
    link  = t.get("link", 0)

    # Log a CSV
    ts = datetime.now().isoformat(timespec="milliseconds")
    with open(LOG_PATH, "a") as f:
        f.write(f"{ts},{armed},{t.get('pwmL',0)},{t.get('pwmR',0)},"
                f"{vbat},{t.get('ch1',0)},{t.get('ch2',0)},{link}\n")

    # Consola
    estado = "ARMADO" if armed else "seguro"
    enlace = "OK" if link else "SIN SEÑAL"
    print(f"[{ts}] {estado} | L={t.get('pwmL',0):>4} R={t.get('pwmR',0):>4} "
          f"| V={vbat:>5.2f} | radio {enlace}")

    # Vigilancia de bateria
    if vbat < VBAT_CRIT and vbat > 1.0:
        print("[rover] BATERIA CRITICA -> freno remoto")
        Bridge.call("soft_stop")
    elif vbat < VBAT_WARN and not warned and vbat > 1.0:
        print(f"[rover] aviso: bateria en {vbat:.2f} V")
        warned = True

    time.sleep(PERIOD)


def main():
    print("[rover] supervision iniciada — el control corre en el MCU")

    # Cabecera del CSV
    with open(LOG_PATH, "w") as f:
        f.write("timestamp,armado,pwmL,pwmR,vbat,ch1,ch2,link\n")

    try:
        App.run(user_loop=loop)
    except KeyboardInterrupt:
        print("\n[rover] supervision detenida. El MCU sigue con su failsafe propio.")


if __name__ == "__main__":
    main()
