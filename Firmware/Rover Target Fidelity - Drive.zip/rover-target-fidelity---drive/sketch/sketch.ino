/* ============================================================================
   ROVER "Target Fidelity"  —  App Lab · lado MCU (sketch)
   SEBDev / Stardance                              Arduino UNO Q · STM32U585

   Este sketch corre en el MICROCONTROLADOR del UNO Q (el STM32, en tiempo real).
   Hace todo lo que no puede esperar: leer el radio, calcular la direccion
   Ackermann, rampar la traccion y cortar por seguridad.

   La otra mitad (python/main.py, en el lado Linux) NO conduce — solo supervisa:
   le pide telemetria a este sketch por el Bridge y la registra. La conduccion
   tiene que vivir aca abajo, en el MCU, porque Linux no es de tiempo real y no
   quiero que un hipo del sistema operativo deje al rover sin frenos.

   Reparto de hardware (por que asi):
   -----------------------------------------------------------------------------
   Tengo DOS drivers BTS7960, no seis. Cada uno mueve los TRES motores de un lado
   en paralelo -> el rover conduce como un tanque, un mando de traccion por lado.
   Los tres motores de un lado siempre giran juntos en un rocker-bogie con
   direccion por servos, asi que un driver por rueda no aportaria nada.

   La DIRECCION la hacen 4 servos MG996R en las esquinas (las del medio son fijas),
   por un PCA9685. Geometria Ackermann con el metodo del ICR comun sobre la linea
   de la rueda del medio (How to Mechatronics): las 4 esquinas apuntan al mismo
   centro de giro, por eso las traseras giran al reves de las delanteras.

   El CONTROL es un FS-i6X -> receptor FLI14+ -> iBUS (un pin serial trae los 14
   canales). El FLI14+ solo saca iBUS, asi que es justo lo que este codigo espera.

   Bridge (comunicacion con Python):
   -----------------------------------------------------------------------------
   Expongo funciones que el lado Linux puede llamar como si fueran locales:
     - get_telemetry()  -> devuelve un string con el estado (armado, PWM, V, etc.)
     - soft_stop()      -> para la traccion desde Python (freno remoto extra)
   Todo el control sigue siendo autonomo en el MCU; el Bridge es supervision.
   ============================================================================ */

#include <Arduino_RouterBridge.h>
#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>

// ---------------------------------------------------------------------------
// PINES
// ---------------------------------------------------------------------------
const uint8_t L_RPWM = 5,  L_LPWM = 6,  L_EN = 7;    // driver lado izquierdo
const uint8_t R_RPWM = 9,  R_LPWM = 10, R_EN = 8;    // driver lado derecho
const uint8_t PIN_IS_L = A2, PIN_IS_R = A3, PIN_VBAT = A0;

// El iBUS entra por un UART del MCU. OJO: en el UNO Q el arduino-router bloquea
// algunos seriales; usa uno libre para el receptor. Aqui Serial1 (ajusta segun
// el mapeo de tu core).
#define IBUS_SERIAL Serial1

// ---------------------------------------------------------------------------
// PCA9685 — servos de direccion
// ---------------------------------------------------------------------------
Adafruit_PWMServoDriver pca = Adafruit_PWMServoDriver(0x40, Wire);

const uint8_t SV_FL = 0;   // front-left
const uint8_t SV_FR = 1;   // front-right
const uint8_t SV_RL = 2;   // rear-left
const uint8_t SV_RR = 3;   // rear-right

// Pulsos del servo (ticks del PCA a 50Hz). Calibra CADA servo: 90 = recto.
const uint16_t SERVO_MIN = 150;   // ~-45 grados de rueda
const uint16_t SERVO_MID = 375;   // rueda recta
const uint16_t SERVO_MAX = 600;   // ~+45 grados de rueda
int servoTrim[4] = {0, 0, 0, 0};
const float MAX_STEER_DEG = 45.0f;

// ---------------------------------------------------------------------------
// GEOMETRIA ACKERMANN (config JPL, dirigen las 4 esquinas)
// ---------------------------------------------------------------------------
const float L_FRONT = 567.0f;    // mm rueda delantera -> linea media
const float L_REAR  = 433.0f;    // mm rueda trasera   -> linea media
const float HALF_TRACK = 350.0f; // mm medio ancho de via
const float R_MIN = 700.0f;      // mm radio de giro minimo al centro del rover

// ---------------------------------------------------------------------------
// TRACCION
// ---------------------------------------------------------------------------
const int   PWM_MAX     = 255;
const uint8_t RAMP_STEP = 4;
const uint16_t RAMP_MS  = 15;
int curL = 0, curR = 0, tgtL = 0, tgtR = 0;

// ---------------------------------------------------------------------------
// RADIO iBUS
// ---------------------------------------------------------------------------
const uint8_t IBUS_LEN = 32;
uint8_t  ibusBuf[IBUS_LEN];
uint8_t  ibusIdx = 0;
uint16_t ch[10] = {1500,1500,1000,1500,1000,1500,1500,1500,1500,1500};
unsigned long lastIbusMs = 0;
const uint16_t FAILSAFE_MS = 500;

bool armed = false;
bool pyStop = false;                 // freno remoto desde Python (Bridge)

// ---------------------------------------------------------------------------
// SEGURIDAD
// ---------------------------------------------------------------------------
const float V_MIN = 10.5f;
float vbat = 12.0f;
unsigned long tLastRamp = 0;

// ============================================================================
void setup() {
  Bridge.begin();                    // arranca el RPC con el lado Linux
  IBUS_SERIAL.begin(115200);         // iBUS 115200 8N1

  pinMode(L_RPWM, OUTPUT); pinMode(L_LPWM, OUTPUT); pinMode(L_EN, OUTPUT);
  pinMode(R_RPWM, OUTPUT); pinMode(R_LPWM, OUTPUT); pinMode(R_EN, OUTPUT);
  driveSide(L_RPWM, L_LPWM, 0);
  driveSide(R_RPWM, R_LPWM, 0);
  setEnable(false);

#if defined(analogReadResolution)
  analogReadResolution(12);
#endif

  Wire.begin();
  pca.begin();
  pca.setPWMFreq(50);
  centerSteering();

  // Funciones que Python puede llamar por el Bridge (supervision, no conduccion)
  Bridge.provide("get_telemetry", get_telemetry);
  Bridge.provide("soft_stop", soft_stop);
}

// ============================================================================
void loop() {
  Bridge.update();                   // atiende llamadas del lado Linux
  readIbus();
  checkFailsafe();
  readArm();
  vbat = readVbat();

  applySteering();
  applyThrottle();
  rampAndDrive();
}

// ============================================================================
// FUNCIONES EXPUESTAS POR EL BRIDGE (las llama Python)
// ============================================================================

// Devuelve la telemetria como string "k=v" separado por comas. Python lo parsea.
String get_telemetry() {
  String s = "";
  s += "arm=";  s += armed ? 1 : 0;
  s += ",pwmL="; s += curL;
  s += ",pwmR="; s += curR;
  s += ",vbat="; s += String(vbat, 2);
  s += ",ch1=";  s += ch[0];
  s += ",ch2=";  s += ch[1];
  s += ",link="; s += (millis() - lastIbusMs < FAILSAFE_MS) ? 1 : 0;
  return s;
}

// Freno remoto desde Python: para la traccion. NO reemplaza al failsafe del MCU,
// es una capa extra (ej. si el lado de vision detecta un obstaculo).
int soft_stop() {
  pyStop = true;
  tgtL = tgtR = 0;
  return 1;
}

// ============================================================================
// DIRECCION ACKERMANN
// ============================================================================
void applySteering() {
  float steer = (ch[0] - 1500) / 500.0f;
  steer = constrain(steer, -1.0f, 1.0f);
  if (fabs(steer) < 0.05f) { centerSteering(); return; }

  float invR = fabs(steer) / R_MIN;
  float R = 1.0f / invR;
  float b = HALF_TRACK;

  float front_in  = degAtan(L_FRONT, R - b);
  float front_out = degAtan(L_FRONT, R + b);
  float rear_in   = degAtan(L_REAR,  R - b);
  float rear_out  = degAtan(L_REAR,  R + b);

  float aFL, aFR, aRL, aRR;
  if (steer > 0) {                   // giro a la DERECHA: interior = derechas
    aFR =  front_in;   aFL =  front_out;
    aRR = -rear_in;    aRL = -rear_out;
  } else {                           // giro a la IZQUIERDA: interior = izquierdas
    aFL = -front_in;   aFR = -front_out;
    aRL =  rear_in;    aRR =  rear_out;
  }

  writeSteer(SV_FL, aFL);
  writeSteer(SV_FR, aFR);
  writeSteer(SV_RL, aRL);
  writeSteer(SV_RR, aRR);
}

float degAtan(float opp, float adj) {
  if (adj <= 1.0f) adj = 1.0f;
  return degrees(atan2(opp, adj));
}

void writeSteer(uint8_t servo, float deg) {
  deg = constrain(deg, -MAX_STEER_DEG, MAX_STEER_DEG);
  float t = SERVO_MID + (deg / MAX_STEER_DEG) * (SERVO_MAX - SERVO_MID);
  uint16_t ticks = (uint16_t)constrain(t + servoTrim[servo], (float)SERVO_MIN, (float)SERVO_MAX);
  pca.setPWM(servo, 0, ticks);
}

void centerSteering() {
  writeSteer(SV_FL, 0); writeSteer(SV_FR, 0);
  writeSteer(SV_RL, 0); writeSteer(SV_RR, 0);
}

// ============================================================================
// TRACCION
// ============================================================================
void applyThrottle() {
  if (!armed || pyStop) { tgtL = tgtR = 0; return; }

  float thr = (ch[1] - 1500) / 500.0f;
  thr = constrain(thr, -1.0f, 1.0f);
  if (fabs(thr) < 0.05f) thr = 0;

  float vmax = (ch[2] - 1000) / 1000.0f;
  vmax = constrain(vmax, 0.0f, 1.0f);

  float steer = (ch[0] - 1500) / 500.0f;
  steer = constrain(steer, -1.0f, 1.0f);
  float inner = 1.0f - 0.4f * fabs(steer);

  float baseL = thr * vmax * PWM_MAX;
  float baseR = thr * vmax * PWM_MAX;
  if (steer > 0)      baseR *= inner;
  else if (steer < 0) baseL *= inner;

  tgtL = (int)constrain(baseL, (float)-PWM_MAX, (float)PWM_MAX);
  tgtR = (int)constrain(baseR, (float)-PWM_MAX, (float)PWM_MAX);
}

void rampAndDrive() {
  if (millis() - tLastRamp < RAMP_MS) return;
  tLastRamp = millis();
  curL = ramp(curL, tgtL);
  curR = ramp(curR, tgtR);
  setEnable(armed && !pyStop && vbat > V_MIN);
  driveSide(L_RPWM, L_LPWM, curL);
  driveSide(R_RPWM, R_LPWM, curR);
}

int ramp(int cur, int tgt) {
  if (cur == tgt) return cur;
  int d = tgt - cur;
  if (abs(d) <= RAMP_STEP) return tgt;
  return cur + (d > 0 ? RAMP_STEP : -RAMP_STEP);
}

void driveSide(uint8_t rpwm, uint8_t lpwm, int pwm) {
  pwm = constrain(pwm, -PWM_MAX, PWM_MAX);
  if (pwm >= 0) { analogWrite(lpwm, 0); analogWrite(rpwm, pwm); }
  else          { analogWrite(rpwm, 0); analogWrite(lpwm, -pwm); }
}

void setEnable(bool on) {
  digitalWrite(L_EN, on ? HIGH : LOW);
  digitalWrite(R_EN, on ? HIGH : LOW);
}

// ============================================================================
// RADIO iBUS
// ============================================================================
void readIbus() {
  while (IBUS_SERIAL.available()) {
    uint8_t b = IBUS_SERIAL.read();
    if (ibusIdx == 0 && b != 0x20) continue;
    ibusBuf[ibusIdx++] = b;
    if (ibusIdx == IBUS_LEN) {
      ibusIdx = 0;
      uint16_t sum = 0xFFFF;
      for (int i = 0; i < 30; i++) sum -= ibusBuf[i];
      uint16_t chk = ibusBuf[30] | (ibusBuf[31] << 8);
      if (sum == chk) {
        for (int c = 0; c < 10; c++)
          ch[c] = ibusBuf[2 + c*2] | (ibusBuf[3 + c*2] << 8);
        lastIbusMs = millis();
        pyStop = false;              // al recibir señal valida, libero el freno de Python
      }
    }
  }
}

void checkFailsafe() {
  if (millis() - lastIbusMs > FAILSAFE_MS) {
    armed = false;
    tgtL = tgtR = 0; curL = curR = 0;
    driveSide(L_RPWM, L_LPWM, 0);
    driveSide(R_RPWM, R_LPWM, 0);
    setEnable(false);
    centerSteering();
  }
}

void readArm() {
  bool sw = ch[4] > 1500;
  bool thrNeutral = fabs((ch[1] - 1500) / 500.0f) < 0.1f;
  if (sw && thrNeutral) armed = true;
  if (!sw) armed = false;
}

float readVbat() {
  long acc = 0;
  for (int i = 0; i < 8; i++) acc += analogRead(PIN_VBAT);
  const float VDIV = (33.0f + 10.0f) / 10.0f;
  return (acc / 8.0f) * 3.3f / 4095.0f * VDIV;
}
